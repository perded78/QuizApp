package com.example.myquizapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import com.example.myquizapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

        //start off with 0 points out of 7 question
    private lateinit var binding: ActivityMainBinding
    private var correctAnswer: String? = null
    private var correctAnswerCount= 0
    private var quizCount = 1
    private val QUIZ__COUNT = 7

    //questions and choices for the quiz
    private val quizData = mutableListOf(
        mutableListOf(" which area do you aim for to kill a zombie? "," the leg"," the head","the shoulder"," the torso"),
        mutableListOf(" which option is the safest to eat? "," a rotten apple"," a can of beans","left over shoe"," a jar of dirt"),
        mutableListOf(" which weapon would be more useful to your survival? "," a stick"," a gun"," a chair"," hair extensions"),
        mutableListOf(" when hiding from a horde of zombies which is the safer option? "," a broken car"," an abandon house"," a garbage can","in a tree"),
        mutableListOf(" where would you have the best luck in finding supplies? "," the trunk of a car "," the super market"," a trash can"," a microwave"),
        mutableListOf(" which is the one best suitable for drinking? "," alcohol"," a bottle of water"," a bottle of soda","  rotten milk"),
        mutableListOf(" best option to start a fire  "," a pile of wet leaves"," dry logs of wood"," plastic containers  "," bucket of ice "),


    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        quizData.shuffle()
        showNextQuiz()
    }
    fun showNextQuiz(){

        binding.countLabel.text = getString(R.string.count_label, quizCount)

        val quiz = quizData[0]

        binding.questionLabel.text = quiz[0]
        correctAnswer = quiz[2]

        quiz.removeAt(0)
        //randomizes the order of questions and choices available
        quiz.shuffle()


        binding.answerBtn1.text = quiz[0]
        binding.answerBtn2.text = quiz[1]
        binding.answerBtn3.text = quiz[2]
        binding.answerBtn4.text = quiz[3]


        quizData.removeAt(0)
        }
    fun checkAnswer(view: View) {

        val answerBtn: Button = findViewById(view.id)
        val btnText = answerBtn.text.toString()

        val alertTitle: String
        if (btnText == correctAnswer) {

            // give the message correct if the answer is correct
            alertTitle = "Correct!"
            correctAnswerCount++
        }
        // give the message correct if the answer is incorrect
        else{
            alertTitle = "Incorrect"
        }
        //gives a right or wrong option depending on your choice
        AlertDialog.Builder(this)
            .setTitle(alertTitle)
            .setMessage("Answer: $correctAnswer")
            .setPositiveButton("OK") {
                    _, _ -> checkQuizCount()
            }
            .setCancelable(false)
            .show()
    }
    private fun checkQuizCount(){

        if(quizCount == QUIZ__COUNT){

            val intent = Intent(this@MainActivity, ResultPage::class.java)
            intent.putExtra("RIGHT_ANSWER_COUNT", correctAnswerCount)
            startActivity(intent)
        }
        else{
            quizCount++
            showNextQuiz()
        }

    }
}