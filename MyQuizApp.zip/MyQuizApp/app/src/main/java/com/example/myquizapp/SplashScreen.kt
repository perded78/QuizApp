package com.example.myquizapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler


class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spalsh_screen)


        supportActionBar?.hide()


        //5 second delay for the splash screen
        Handler().postDelayed({

            val int = Intent(this,MainActivity::class.java)
            startActivity(int)
            finish()



        },  3000 )


    }
}